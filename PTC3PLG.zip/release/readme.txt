==================================
 SmileBASIC-CYX GitHub test build
      2022-2023 CyberYoshi64
==================================

Thank you for your interest in SmileBASIC-CYX.

------------
 Disclaimer
------------

This is a test build, coming straight from the latest compilation of this plugin at the time of its associated commit.

The plugin may be unstable or contain bugs that CyberYoshi64 did not catch.
So please don't contact him and complain that it crashes here and there, m'kay?

------------
 How to use
------------

The "luma" and "PTC3PLG" folders go on the root of the SD Card.
The folders must be copied over together, otherwise some errors might show their ugly faces.

Afterwards, ensure on your 3DS that the plugin loader is enabled.
To do so, press the hotkeys for Rosalina Menu (by default, it's L + D-Pad Down + SELECT)
Then check if "Plugin Loader" is set to "[Enabled]". If it isn't select it once to toggle it.
If you don't have the Plugin Loader, please update your Luma. (https://github.com/LumaTeam/Luma3DS/releases)

Then just start SmileBASIC 3. If everything went right, the Nintendo 3DS logo should flash blue and the TOP MENU appears with a dark theme.